#include <iostream>
using namespace std;

// Inventory class
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:
    void setData(int sn, int year, int lot) {
        serialNum = sn;
        manufactYear = year;
        lotNum = lot;
    }

    void display() {
        cout << "Serial Number: " << serialNum 
             << ", Manufactured Year: " << manufactYear
             << ", Lot Number: " << lotNum << endl;
    }
};

// Node for Linked List Stack
struct Node {
    Inventory data;
    Node* next;
};

// Stack class using Linked List
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = NULL;
    }

    // Push inventory object to stack
    void push(Inventory obj) {
        Node* newNode = new Node;
        newNode->data = obj;
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory successfully!" << endl;
    }

    // Pop object from stack
    void pop() {
        if (top == NULL) {
            cout << "Inventory is empty! Nothing to remove." << endl;
            return;
        }

        cout << "Part removed from inventory:\n";
        top->data.display();

        Node* temp = top;
        top = top->next;
        delete temp;
    }

    // Display remaining items
    void display() {
        if (top == NULL) {
            cout << "Inventory is empty!" << endl;
            return;
        }

        cout << "\nRemaining Parts in Inventory:\n";
        Node* temp = top;
        while (temp != NULL) {
            temp->data.display();
            temp = temp->next;
        }
        cout << endl;
    }
};

// Main program
int main() {
    Stack s;
    int choice;

    do {
        cout << "\n=== Inventory Management System ===\n";
        cout << "1. Add part to inventory (Push)\n";
        cout << "2. Remove part from inventory (Pop)\n";
        cout << "3. Exit and show remaining parts\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int sn, year, lot;
            cout << "Enter Serial Number: ";
            cin >> sn;
            cout << "Enter Manufacture Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            Inventory obj;
            obj.setData(sn, year, lot);
            s.push(obj);
        }
        else if (choice == 2) {
            s.pop();
        }
        else if (choice == 3) {
            cout << "\nExiting program..." << endl;
        }
        else {
            cout << "Invalid choice! Try again.\n";
        }

    } while (choice != 3);

    s.display();

    return 0;
}


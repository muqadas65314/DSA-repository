#include <iostream>
using namespace std;

// Node structure for Book
struct Node {
    string title;
    int price;
    int edition;
    int pages;
    Node *next;
};


Node *top = NULL;

// Push Function for adding books 
void push(string t, int p, int e, int pg) {
    Node *newNode = new Node;
    newNode->title = t;
    newNode->price = p;
    newNode->edition = e;
    newNode->pages = pg;
    newNode->next = top;
    top = newNode;
    cout << "\nBook Pushed: " << t << endl;
}

// Pop Function for deleteing 2 book form top
void pop() {
    if (top == NULL) {
        cout << "Stack Underflow! No books to pop.\n";
        return;
    }
    
    Node *temp = top;
    top = top->next;
      cout << "\nBook Popped: " << temp->title << endl;
    delete temp;
  
}

// Peek Function - show top book
void peek() {
    if (top == NULL) {
        cout << "Stack Empty! No top book.\n";
        return;
    }
    cout << "\nTop Book Details:\n\n\n";
    cout << "Title: " << top->title <<"\t"
         << "Price: " << top->price  <<"\t"
         << "Edition: " << top->edition  <<"\t"
         << ", Pages: " << top->pages << endl; 
}

// Display Function - show all books
void display() {
    if (top == NULL) {
        cout << "Stack Empty!\n";
        return;
    }
    cout << "\n--- Books in Stack ---\n\n\n";
    Node *temp = top;
    while (temp != NULL) {
        cout << "Title: " << temp->title  <<"\t"
             << ", Price: " << temp->price <<"\t"
             << ", Pages: " << temp->pages << endl; 
        temp = temp->next;
    }
}

int main() {

    // ? 1. Push 5 Books
    push("Java", 500, 3, 350);
    push("C++", 700, 4, 450);
    push("Python", 600, 2, 300);
    push("DSA", 800, 5, 500);
    push("OOP", 550, 3, 400);

    // ? 2. Find Top Book
    peek();

    // ? 3. Pop 2 Books
    pop();
    pop();

    // ? 4. Display Remaining Books
    display();

    return 0;
}


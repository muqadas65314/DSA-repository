#include <iostream>
using namespace std;

int main() {
    // Struct definition inside main
    struct Dlist {
        int data;
        Dlist* next;
        Dlist* prev;
    };

    Dlist* head = NULL;
    Dlist* tail = NULL;

    int n;
    cout << "Enter number of marks: ";
    cin >> n;

    // ------------------ CREATE LIST ------------------
    for(int i=0; i<n; i++) {
        int val;
        cout << "Enter mark " << i+1 << ": ";
        cin >> val;

        Dlist* newNode = new Dlist;
        newNode->data = val;
        newNode->next = NULL;
        newNode->prev = NULL;

        if(head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    // ------------------ DISPLAY LIST ------------------
    cout << "Marks in list: ";
    Dlist* temp = head;
    while(temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ------------------ ADD AT BEGINNING ------------------
    cout << "\nAdding at beginning (value=100):\n";
    Dlist* newNode = new Dlist;
    newNode->data = 100;
    newNode->next = head;
    newNode->prev = NULL;
    if(head != NULL) head->prev = newNode;
    head = newNode;

    // Display after addition
    cout << "Marks in list: ";
    temp = head;
    while(temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ------------------ ADD AFTER 45 ------------------
    cout << "\nAdding after 45 (value=200):\n";
    temp = head;
    while(temp != NULL && temp->data != 45) {
        temp = temp->next;
    }
    if(temp == NULL) {
        cout << "Value 45 not found!" << endl;
    } else {
        Dlist* newNode2 = new Dlist;
        newNode2->data = 200;
        newNode2->next = temp->next;
        newNode2->prev = temp;
        if(temp->next != NULL) temp->next->prev = newNode2;
        temp->next = newNode2;
    }

    // Display after addition
    cout << "Marks in list: ";
    temp = head;
    while(temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ------------------ DELETE AT BEGINNING ------------------
    cout << "\nDeleting at beginning:\n";
    if(head == NULL) {
        cout << "List is empty!" << endl;
    } else {
        Dlist* delNode = head;
        head = head->next;
        if(head != NULL) head->prev = NULL;
        delete delNode;
    }

    // Display after deletion
    cout << "Marks in list: ";
    temp = head;
    while(temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ------------------ DELETE AFTER 45 ------------------
    cout << "\nDeleting after 45:\n";
    temp = head;
    while(temp != NULL && temp->data != 45) {
        temp = temp->next;
    }
    if(temp == NULL || temp->next == NULL) {
        cout << "No node exists after 45!" << endl;
    } else {
        Dlist* delNode2 = temp->next;
        temp->next = delNode2->next;
        if(delNode2->next != NULL) delNode2->next->prev = temp;
        delete delNode2;
    }

    // Display final list
    cout << "Marks in list: ";
    temp = head;
    while(temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    return 0;
}


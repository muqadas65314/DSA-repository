#include <iostream>
#include <string>
using namespace std;

int main() {
    
    struct Player {
        string name;
        int score;
        Player* next;
        Player* prev;
    };

    Player* head = NULL;
    Player* tail = NULL;

    int choice;
    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add New Player\n2. Delete Player\n3. Display All Players (Ascending)\n";
        cout << "4. Display All Players (Descending)\n5. Display Player(s) with Lowest Score\n";
        cout << "6. Display Players with Specific Score\n7. Display Backward From Player\n8. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if(choice == 1) {
            string name;
            int score;
            cout << "Enter player name: ";
            cin >> name;
            do {
                cout << "Enter player score: ";
                cin >> score;
                if(score < 0) cout << "Score cannot be negative! Try again.\n";
            } while(score < 0);

            // ------------------ ADD PLAYER IN SORTED ORDER ------------------
            Player* newNode = new Player{name, score, NULL, NULL};
            if(head == NULL) { // empty list
                head = tail = newNode;
            } else if(score <= head->score) { // insert at beginning
                newNode->next = head;
                head->prev = newNode;
                head = newNode;
            } else {
                Player* temp = head;
                while(temp->next != NULL && temp->next->score < score) {
                    temp = temp->next;
                }
                newNode->next = temp->next;
                newNode->prev = temp;
                if(temp->next != NULL) temp->next->prev = newNode;
                temp->next = newNode;
                if(newNode->next == NULL) tail = newNode;
            }
            cout << "Player added successfully.\n";

        } else if(choice == 2) {
            string name;
            cout << "Enter player name to delete: ";
            cin >> name;

            Player* temp = head;
            while(temp != NULL && temp->name != name) temp = temp->next;

            if(temp == NULL) {
                cout << "Player not found!\n";
            } else {
                if(temp == head) {
                    head = head->next;
                    if(head != NULL) head->prev = NULL;
                } else if(temp == tail) {
                    tail = tail->prev;
                    tail->next = NULL;
                } else {
                    temp->prev->next = temp->next;
                    temp->next->prev = temp->prev;
                }
                delete temp;
                cout << "Player deleted successfully.\n";
            }

        } else if(choice == 3) { // Display ascending
            if(head == NULL) cout << "No players in list!\n";
            else {
                cout << "Players in ascending order:\n";
                Player* temp = head;
                while(temp != NULL) {
                    cout << temp->name << " - " << temp->score << endl;
                    temp = temp->next;
                }
            }

        } else if(choice == 4) { // Display descending
            if(tail == NULL) cout << "No players in list!\n";
            else {
                cout << "Players in descending order:\n";
                Player* temp = tail;
                while(temp != NULL) {
                    cout << temp->name << " - " << temp->score << endl;
                    temp = temp->prev;
                }
            }

        } else if(choice == 5) { // Lowest score
            if(head == NULL) cout << "No players in list!\n";
            else {
                int lowest = head->score;
                cout << "Players with lowest score (" << lowest << "):\n";
                Player* temp = head;
                while(temp != NULL && temp->score == lowest) {
                    cout << temp->name << endl;
                    temp = temp->next;
                }
            }

        } else if(choice == 6) { // Players with specific score
            if(head == NULL) cout << "No players in list!\n";
            else {
                int score;
                cout << "Enter score to search: ";
                cin >> score;
                Player* temp = head;
                bool found = false;
                cout << "Players with score " << score << ":\n";
                while(temp != NULL) {
                    if(temp->score == score) {
                        cout << temp->name << endl;
                        found = true;
                    }
                    temp = temp->next;
                }
                if(!found) cout << "No players found with this score.\n";
            }

        } else if(choice == 7) { // Display backward from a player
            if(head == NULL) cout << "No players in list!\n";
            else {
                string name;
                cout << "Enter player name to display backward from: ";
                cin >> name;
                Player* temp = head;
                while(temp != NULL && temp->name != name) temp = temp->next;

                if(temp == NULL) cout << "Player not found!\n";
                else {
                    cout << "Players behind " << name << ":\n";
                    Player* back = temp->prev;
                    while(back != NULL) {
                        cout << back->name << " - " << back->score << endl;
                        back = back->prev;
                    }
                }
            }

        } else if(choice == 8) {
            cout << "Exiting program.\n";
        } else {
            cout << "Invalid choice! Try again.\n";
        }

    } while(choice != 8);

    return 0;
}


#include <iostream>
using namespace std;

int main() {
    // Struct definition inside main
    struct Dlist {
        int data;
        Dlist* next;
        Dlist* prev;
    };

    Dlist* head = NULL;
    Dlist* tail = NULL;

    const int DAYS = 7;
    int n = DAYS;
    int val;

    cout << "Enter rainfall for 7 days (non-negative only):\n";

    // ------------------ CREATE LIST ------------------
    for(int i = 0; i < n; i++) {
        do {
            cout << "Day " << i+1 << ": ";
            cin >> val;
            if(val < 0) cout << "Invalid input! Rainfall cannot be negative. Try again.\n";
        } while(val < 0);

        Dlist* newNode = new Dlist;
        newNode->data = val;
        newNode->next = NULL;
        newNode->prev = NULL;

        if(head == NULL) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    // ------------------ DISPLAY LIST ------------------
    cout << "\nRainfall for the week: ";
    Dlist* temp = head;
    while(temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ------------------ CALCULATE TOTAL & AVERAGE ------------------
    int total = 0;
    int highest = head->data;
    int lowest = head->data;
    int day = 1, day_high = 1, day_low = 1;
    temp = head;
    int count = 1;

    while(temp != NULL) {
        total += temp->data;

        if(temp->data > highest) {
            highest = temp->data;
            day_high = count;
        }

        if(temp->data < lowest) {
            lowest = temp->data;
            day_low = count;
        }

        temp = temp->next;
        count++;
    }

    double average = static_cast<double>(total) / n;

    cout << "\nTotal rainfall for the week: " << total << endl;
    cout << "Average weekly rainfall: " << average << endl;
    cout << "Day with highest rainfall: Day " << day_high << " (" << highest << ")" << endl;
    cout << "Day with lowest rainfall: Day " << day_low << " (" << lowest << ")" << endl;

    // ------------------ RAINFALL OF DAY AFTER 5TH NODE ------------------
    temp = head;
    count = 1;
    while(temp != NULL && count < 5) {
        temp = temp->next;
        count++;
    }

    if(temp != NULL && temp->next != NULL) {
        cout << "Rainfall of day after 5th day: " << temp->next->data << endl;
    } else {
        cout << "No day exists after 5th day!" << endl;
    }

    return 0;
}


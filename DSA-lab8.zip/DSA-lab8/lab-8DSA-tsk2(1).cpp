#include<iostream>
using namespace std;

struct Truck {
    int id;
    Truck* next;
};

Truck* roadFront = NULL; 
Truck* roadRear = NULL;  
Truck* garageTop = NULL;

// Road ? Queue (enqueue)
void On_road(int tid) {
    Truck* t = new Truck;
    t->id = tid;// truck id =tid
    t->next = NULL;

    if(roadFront == NULL) {
        roadFront = t;
        roadRear = t;
    } else {
        roadRear->next = t;//  link first with next
        roadRear = t;// change rear to new one node 
    }
    cout << "Truck " << tid << " is now ON ROAD.\n";
}

// Road ? Garage (stack push)
void Enter_garage() {
    if(roadFront == NULL) {
        cout << "No truck on road\n";
        return;
    }

    Truck* t = roadFront;
    roadFront = roadFront->next;// change front to next 
    if(roadFront == NULL) roadRear = NULL; 

    t->next = garageTop;
    garageTop = t;

    cout << "Truck " << t->id << " ENTERED GARAGE\n";
}

// Garage ? Road (stack pop)
void Exit_garage(int tid) {

    if(garageTop == NULL) {
        cout << "Garage empty!\n";
        return;
    }

    if(garageTop->id != tid) {
        cout << "Truck is not near garage door\n";
        return;
    }

    Truck* temp = garageTop;
    garageTop = garageTop->next;
    cout << "Truck " << temp->id << " EXITED GARAGE\n";
    delete temp;
}

// Show trucks
void Show_road() {
    cout << "\nTrucks ON ROAD:\n";
    Truck* p = roadFront;
    if(p == NULL) {
        cout << "None\n"; return;
    }
    while(p != NULL) {
        cout << p->id << " ";
        p = p->next;
    }
    cout << endl;
}

void Show_garage() {
    cout << "\nTrucks IN GARAGE:\n";
    Truck* p = garageTop;
    if(p == NULL) {
        cout << "None\n"; return;
    }
    while(p != NULL) {
        cout << p->id << " ";
        p = p->next;
    }
    cout << endl;
}

int main() {

    // Scenario execution (manual, simple, direct)
    On_road(111);
    On_road(222);
    On_road(333);
    On_road(4444);

    Show_road();

    Enter_garage();
    Enter_garage();

    Show_garage();

    Exit_garage(30); // ? allowed
    Exit_garage(10); // ? not allowed

    Show_garage();
    Show_road();

    return 0;
}

